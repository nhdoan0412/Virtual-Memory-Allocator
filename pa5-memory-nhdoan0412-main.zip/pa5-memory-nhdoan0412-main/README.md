Assignment specifications: https://cse29sp24.github.io/docs/pas/pa5.html
