#include "vm.h"
#include "vmlib.h"

void *vmalloc(size_t size)
{
    // TODO
    // Check if size is greater than 0
    if (size == 0) {
        return NULL;
    }

    // Calculate the actual block size needed
    size_t block_size = ROUND_UP(size + sizeof(struct block_header), BLKALIGN);

    // Traverse the heap to find the best-fitting block (best-fit policy)
    struct block_header *curr_block = heapstart;
    struct block_header *best_block = NULL;
    size_t best_size = SIZE_MAX; // Initialize to maximum possible size

    while (curr_block->size_status != VM_ENDMARK) {
        size_t curr_size = BLKSZ(curr_block);
        if (!(curr_block->size_status & VM_BUSY) && curr_size >= block_size &&
            curr_size < best_size) {
            best_block = curr_block;
            best_size = curr_size;
        }
        curr_block = (struct block_header*)((uint8_t*)curr_block + curr_size);
    }

    // If no suitable block found, return NULL
    if (best_block == NULL) {
        return NULL;
    }

    // Split the block if it's larger than needed
    if (best_size > block_size) {
        struct block_header *created_block =
            (struct block_header*)((uint8_t*)best_block + block_size);
        created_block->size_status = best_size - block_size | VM_PREVBUSY;
        best_block->size_status = block_size | VM_BUSY | VM_PREVBUSY;

        // Update the footer of the new block
        struct block_footer *created_footer =
            (struct block_footer*)((uint8_t*)created_block + BLKSZ(created_block) -
                                  sizeof(struct block_footer));
        created_footer->size = created_block->size_status;
    } else {
        best_block->size_status |= VM_BUSY;
        struct block_header *next_block =
            (struct block_header*)((uint8_t*)best_block + best_size);
        if (next_block->size_status != VM_ENDMARK) {
            next_block->size_status |= VM_PREVBUSY;
        }
    }

    // Return a pointer to the start of the payload (after the header)
    return (void *)(best_block + 1);
}
