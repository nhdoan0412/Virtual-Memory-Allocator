#include "vm.h"

#include "vmlib.h"

/**
 * The vmfree() function frees the memory space pointed to by ptr,
 * which must have been returned by a previous call to vmmalloc().
 * Otherwise, or if free(ptr) has already been called before,
 * undefined behavior occurs.
 * If ptr is NULL, no operation is performed.
 */
void vmfree(void *ptr)
{
    // TODO
    if (ptr == NULL) {
            return; 
    }
    // luc dau no chi la kieu pointer unsigned integer 8 bit chu chua phai la struct pointer cua block header
//    struct block_header *block = (struct block_header*)((uint8_t*)ptr - sizeof(struct block_header));
    
 //  if(!(block->size_status & VM_BUSY)){ // condition return mot chuoi bit va neu ma no freed roi thi out 
   //     return;
   // }
    
    // 1011 --> 1010 
   // block->size_status = (block->size_status^VM_BUSY);

   // size_t block_size = BLKSZ(block);
    // return the pointer to position of footer in a block 
   // struct block_footer* footer = (struct block_footer*)((uint8_t*)ptr + block_size - sizeof(struct block_footer));
   // footer->size = block->size_status;

    //unset the next block's prev to free 
   // struct block_header *next_block = (struct block_header*)((uint8_t*)block + block_size);
    // vi ptr chi tro vao than con block la con tro chi toi block_header 
    
   // if(next_block->size_status !=VM_ENDMARK){
     //   next_block->size_status =(next_block->size_status^VM_PREVBUSY);
   // }

   // if((next_block->size_status !=VM_ENDMARK) &&(!(next_block->size_status&VM_BUSY))){
    // 1101001 ^0000001 = 11011100
    //Neu bit cuoi cua size status=1 return false 
    // bit ABCDEFGH. Neu ta ca la 0 thi cung return false 
    // 000000 & 0000001 = 000000 -> false -> !false -> true -> run 
    // 0000001 & 000001 = 000001 -> true -> not run
       // block_size += BLKSZ(next_block);
     //   block
   // }

     struct block_header *header = (struct block_header *)((char *)ptr - sizeof(struct block_header));

    if (!(header->size_status & VM_BUSY)) {
        return;
    }

    header->size_status &= ~VM_BUSY;

    size_t block_size = BLKSZ(header);
    struct block_footer *footer = (struct block_footer *)((char *)header + block_size - sizeof(struct block_footer));
    footer->size = block_size;

    struct block_header *next_block = (struct block_header *)((char *)header + block_size);
    if (BLKSZ(next_block) != 0) {
        next_block->size_status &= ~VM_PREVBUSY;
    }

    if (!(next_block->size_status & VM_BUSY)) {
        size_t next_block_size = BLKSZ(next_block);
        block_size += next_block_size;
        header->size_status = block_size | (header->size_status & VM_PREVBUSY);
        footer = (struct block_footer *)((char *)header + block_size - sizeof(struct block_footer));
        footer->size = block_size;
    }

    if (!(header->size_status & VM_PREVBUSY)) {
        struct block_footer *prev_footer = (struct block_footer *)((char *)header - sizeof(struct block_footer));
        size_t prev_block_size = prev_footer->size;
        struct block_header *prev_header = (struct block_header *)((char *)header - prev_block_size);
        block_size += prev_block_size;
        prev_header->size_status = block_size | (prev_header->size_status & VM_PREVBUSY);
        footer->size = block_size;
    }
}
